# Ten experiments in the spice-export project

| No. | Syllabus topic | Project application |
|---|---|---|
| 1 | Responsive Bootstrap registration form and JavaScript validation | `src/pages/RegisterPage.jsx` and `src/components/BuyerForm.jsx` |
| 2 | ES6 functions, arrays, events, and popup boxes | `src/data/spices.js` and the search, filter, and sample actions in `src/components/SpiceCatalog.jsx` |
| 3 | React functional components, JSX, props, and state | `src/components/SpiceCard.jsx`, `src/components/SpiceCatalog.jsx`, and the website pages |
| 4 | SPA routing, Hooks, and lifecycle behavior | `src/App.jsx` and `src/components/SiteLayout.jsx` |
| 5 | MongoDB databases, collections, documents, and CRUD | `experiments/exp5-mongodb.mongosh.js`, `server/src/models/`, and `server/src/seed.js` |
| 6 | Node.js, Express, and Mongoose connection | `server/src/index.js`, `server/src/app.js`, and `server/src/config/database.js` |
| 7 | REPL, HTTP, file system, buffers, streams, and event loop | `experiments/exp7-repl-guide.md` and `experiments/exp7-node-basics.js` |
| 8 | Express REST API and Postman | `server/src/routes/`, `server/src/controllers/`, and `postman/` |
| 9 | MERN integration with Axios | `src/lib/api.js` and the sample-request form |
| 10 | Cloud deployment and end-to-end use | `render.yaml`, `vercel.json`, and `DEPLOYMENT.md` |

## Build order

The frontend is the first visible milestone. Next, use the MongoDB models and CRUD exercises, bring up the Express API, check its routes in Postman, and connect the buyer sample form through Axios. Finish by deploying the API and frontend and testing one sample request from browser to database.
