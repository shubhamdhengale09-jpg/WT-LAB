// Run these commands in mongosh for Experiment 5.
// mongosh

use spice_export_db

db.createCollection('products')
db.createCollection('samplerequests')

db.products.insertOne({
  slug: 'turmeric',
  name: 'Turmeric',
  botanicalName: 'Curcuma longa',
  category: 'Roots',
  note: 'Warm, earthy colour and aroma',
  origin: 'India',
  sampleAvailable: true,
  active: true
})

db.products.find({ active: true })
db.products.updateOne({ slug: 'turmeric' }, { $set: { sampleAvailable: false } })
db.products.findOne({ slug: 'turmeric' })
db.products.deleteOne({ slug: 'turmeric' })

// The Mongoose models in server/src/models create collections from the same
// document shapes when the Express application first saves records.
