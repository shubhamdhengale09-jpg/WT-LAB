import { createServer } from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
import { Buffer } from 'node:buffer';
import { Readable, Transform } from 'node:stream';

// Event loop: this synchronous message appears before the timer callback.
console.log('1. Synchronous Node.js statement');
setTimeout(() => console.log('2. Timer callback (event loop)'), 0);

// Buffer: inspect the UTF-8 byte length of a short catalogue label.
const label = Buffer.from('Turmeric export sample', 'utf8');
console.log('3. Buffer byte length:', label.length);

// File System: write and read a small local text file.
const notePath = new URL('./exp7-note.txt', import.meta.url);
await writeFile(notePath, 'Sample request prepared for Turmeric.\n', 'utf8');
console.log('4. File System read:', (await readFile(notePath, 'utf8')).trim());

// Streams: transform a readable sample line and consume the output.
const upperCase = new Transform({
  transform(chunk, _encoding, callback) {
    callback(null, chunk.toString().toUpperCase());
  },
});
Readable.from(['cumin, coriander, cardamom']).pipe(upperCase).on('data', (chunk) => {
  console.log('5. Stream output:', chunk.toString());
});

// HTTP server: visit http://localhost:5050 while this file is running.
const server = createServer((_request, response) => {
  response.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
  response.end('Spice export Node.js HTTP server is running.');
});
server.listen(5050, () => console.log('6. HTTP server: http://localhost:5050'));

// Stop the demo server with Ctrl+C after observing the response.
