# Experiment 7 Node REPL guide

Start the interactive Node.js REPL by running `node` in a terminal. Try the following expressions:

```js
const spices = ['Turmeric', 'Black Pepper', 'Cardamom'];
spices.length;
spices.map((name) => name.toUpperCase());
Buffer.from('Sample request').length;
```

Then exit the REPL with `.exit`. Run the longer demonstration from the project root with `npm run exp7`; it covers an HTTP server, file reading and writing, a Buffer, a Transform stream, and timer/event-loop output.
