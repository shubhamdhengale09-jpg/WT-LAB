import { Router } from 'express';
import {
  createSampleRequest, deleteSampleRequest, getSampleRequest,
  listSampleRequests, updateSampleRequest,
} from '../controllers/sampleController.js';
import { requireAdmin } from '../middleware/requireAdmin.js';

const router = Router();

router.post('/', async (request, response, next) => {
  try { await createSampleRequest(request, response); } catch (error) { next(error); }
});
router.get('/', requireAdmin, async (request, response, next) => {
  try { await listSampleRequests(request, response); } catch (error) { next(error); }
});
router.get('/:id', requireAdmin, async (request, response, next) => {
  try { await getSampleRequest(request, response); } catch (error) { next(error); }
});
router.put('/:id', requireAdmin, async (request, response, next) => {
  try { await updateSampleRequest(request, response); } catch (error) { next(error); }
});
router.delete('/:id', requireAdmin, async (request, response, next) => {
  try { await deleteSampleRequest(request, response); } catch (error) { next(error); }
});

export default router;
