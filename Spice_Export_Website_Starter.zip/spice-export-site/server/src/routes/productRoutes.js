import { Router } from 'express';
import { createProduct, deleteProduct, listProducts, updateProduct } from '../controllers/productController.js';
import { requireAdmin } from '../middleware/requireAdmin.js';

const router = Router();

router.get('/', async (request, response, next) => {
  try { await listProducts(request, response); } catch (error) { next(error); }
});
router.post('/', requireAdmin, async (request, response, next) => {
  try { await createProduct(request, response); } catch (error) { next(error); }
});
router.put('/:id', requireAdmin, async (request, response, next) => {
  try { await updateProduct(request, response); } catch (error) { next(error); }
});
router.delete('/:id', requireAdmin, async (request, response, next) => {
  try { await deleteProduct(request, response); } catch (error) { next(error); }
});

export default router;
