export function requireAdmin(request, response, next) {
  const expectedKey = process.env.ADMIN_API_KEY;
  const providedKey = request.get('x-admin-api-key');

  if (!expectedKey || expectedKey === 'replace-with-a-private-development-key') {
    return response.status(503).json({ message: 'Configure ADMIN_API_KEY before using admin routes.' });
  }
  if (!providedKey || providedKey !== expectedKey) {
    return response.status(401).json({ message: 'A valid admin API key is required.' });
  }
  return next();
}
