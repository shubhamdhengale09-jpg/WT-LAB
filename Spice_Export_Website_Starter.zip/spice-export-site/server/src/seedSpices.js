export const spices = [
  { slug: 'turmeric', name: 'Turmeric', botanicalName: 'Curcuma longa', category: 'Roots', note: 'Warm, earthy colour and aroma', origin: 'India', sampleAvailable: true },
  { slug: 'black-pepper', name: 'Black Pepper', botanicalName: 'Piper nigrum', category: 'Seeds', note: 'Bold, aromatic peppercorns', origin: 'India', sampleAvailable: true },
  { slug: 'cardamom', name: 'Green Cardamom', botanicalName: 'Elettaria cardamomum', category: 'Pods', note: 'Fragrant pods for sweet and savoury uses', origin: 'India', sampleAvailable: true },
  { slug: 'red-chilli', name: 'Red Chilli', botanicalName: 'Capsicum annuum', category: 'Chillies', note: 'A vivid chilli with a lively finish', origin: 'India', sampleAvailable: true },
  { slug: 'cumin', name: 'Cumin', botanicalName: 'Cuminum cyminum', category: 'Seeds', note: 'Distinctive, toasted and savoury', origin: 'India', sampleAvailable: false },
  { slug: 'coriander', name: 'Coriander Seed', botanicalName: 'Coriandrum sativum', category: 'Seeds', note: 'Citrusy seeds with a gentle warmth', origin: 'India', sampleAvailable: true },
];
