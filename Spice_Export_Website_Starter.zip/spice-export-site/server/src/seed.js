import 'dotenv/config';
import mongoose from 'mongoose';
import { connectDatabase } from './config/database.js';
import Product from './models/Product.js';
import { spices } from './seedSpices.js';

try {
  await connectDatabase();
  for (const spice of spices) {
    await Product.updateOne({ slug: spice.slug }, { $set: { ...spice, active: true } }, { upsert: true });
  }
  console.log(`Seeded ${spices.length} catalogue products.`);
} catch (error) {
  console.error('Could not seed products:', error.message);
  process.exitCode = 1;
} finally {
  await mongoose.disconnect();
}
