import express from 'express';
import cors from 'cors';
import productRoutes from './routes/productRoutes.js';
import sampleRoutes from './routes/sampleRoutes.js';

const app = express();
const allowedOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';

app.use(cors({ origin: allowedOrigin }));
app.use(express.json({ limit: '32kb' }));

app.get('/api/health', (_request, response) => {
  response.json({ status: 'ok', service: 'spice-export-api' });
});

app.use('/api/products', productRoutes);
app.use('/api/samples', sampleRoutes);

app.use((request, response) => {
  response.status(404).json({ message: `Route not found: ${request.method} ${request.path}` });
});

app.use((error, _request, response, _next) => {
  console.error(error);
  response.status(error.status || 500).json({
    message: error.status ? error.message : 'An unexpected server error occurred.',
  });
});

export default app;
