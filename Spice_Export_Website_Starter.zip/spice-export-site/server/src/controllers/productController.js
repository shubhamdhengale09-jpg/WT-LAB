import Product from '../models/Product.js';

export async function listProducts(_request, response) {
  const products = await Product.find({ active: true }).sort({ name: 1 }).lean();
  response.json(products);
}

export async function createProduct(request, response) {
  const product = await Product.create(request.body);
  response.status(201).json(product);
}

export async function updateProduct(request, response) {
  const product = await Product.findByIdAndUpdate(request.params.id, request.body, {
    new: true, runValidators: true,
  });
  if (!product) return response.status(404).json({ message: 'Product not found.' });
  return response.json(product);
}

export async function deleteProduct(request, response) {
  const product = await Product.findByIdAndDelete(request.params.id);
  if (!product) return response.status(404).json({ message: 'Product not found.' });
  return response.status(204).end();
}
