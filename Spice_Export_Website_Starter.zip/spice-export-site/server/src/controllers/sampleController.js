import SampleRequest from '../models/SampleRequest.js';

export async function createSampleRequest(request, response) {
  const requestRecord = await SampleRequest.create(request.body);
  response.status(201).json({
    message: 'Sample request received.',
    request: requestRecord,
  });
}

export async function listSampleRequests(_request, response) {
  const records = await SampleRequest.find().sort({ createdAt: -1 }).lean();
  response.json(records);
}

export async function getSampleRequest(request, response) {
  const record = await SampleRequest.findById(request.params.id).lean();
  if (!record) return response.status(404).json({ message: 'Sample request not found.' });
  return response.json(record);
}

export async function updateSampleRequest(request, response) {
  const record = await SampleRequest.findByIdAndUpdate(request.params.id, request.body, {
    new: true, runValidators: true,
  });
  if (!record) return response.status(404).json({ message: 'Sample request not found.' });
  return response.json(record);
}

export async function deleteSampleRequest(request, response) {
  const record = await SampleRequest.findByIdAndDelete(request.params.id);
  if (!record) return response.status(404).json({ message: 'Sample request not found.' });
  return response.status(204).end();
}
