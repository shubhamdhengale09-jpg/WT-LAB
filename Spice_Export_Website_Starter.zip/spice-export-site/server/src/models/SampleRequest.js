import mongoose from 'mongoose';

const sampleRequestSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 100 },
  company: { type: String, required: true, trim: true, maxlength: 120 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 254 },
  country: { type: String, required: true, trim: true, maxlength: 80 },
  product: { type: String, required: true, trim: true, maxlength: 100 },
  message: { type: String, trim: true, maxlength: 1000, default: '' },
  status: { type: String, enum: ['new', 'reviewing', 'responded', 'closed'], default: 'new' },
}, { timestamps: true });

sampleRequestSchema.index({ createdAt: -1 });

export default mongoose.model('SampleRequest', sampleRequestSchema);
