import mongoose from 'mongoose';

const productSchema = new mongoose.Schema({
  slug: { type: String, required: true, unique: true, trim: true, lowercase: true },
  name: { type: String, required: true, trim: true, maxlength: 80 },
  botanicalName: { type: String, trim: true, maxlength: 100, default: '' },
  category: { type: String, required: true, trim: true, maxlength: 40 },
  note: { type: String, required: true, trim: true, maxlength: 180 },
  origin: { type: String, required: true, trim: true, maxlength: 80 },
  sampleAvailable: { type: Boolean, default: false },
  active: { type: Boolean, default: true },
}, { timestamps: true });

export default mongoose.model('Product', productSchema);
