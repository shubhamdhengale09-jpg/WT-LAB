# Deployment outline

The deployment target is a React frontend on Vercel, an Express API on Render, and MongoDB Atlas. No service has been published yet.

## Before deploying

- Replace the placeholder brand, contact details, office location, and unverified catalogue copy with client-approved information.
- Create a MongoDB Atlas database and keep its URI private.
- Replace the classroom `x-admin-api-key` demonstration with proper authentication and role-based access before exposing private sample-request records.
- Configure production CORS to allow only the deployed frontend origin and add spam protection and an appropriate privacy notice to public enquiry forms.
- Set API mode and `VITE_API_BASE_URL` for the deployed frontend build.

## API service

1. Push this project to a Git repository.
2. Create a Render Web Service using the included `render.yaml` or enter `npm install` and `npm run server` as build/start commands.
3. Add `MONGODB_URI`, `CLIENT_ORIGIN`, and `ADMIN_API_KEY` as private service environment variables.
4. Confirm `GET /api/health` returns a healthy response.
5. Run the seed script once using the Render shell or a trusted local connection.

## Frontend

1. Import the project into Vercel and set the project root to this folder.
2. Use `npm run build` and the `dist` output directory.
3. Set `VITE_API_ENABLED=true` and `VITE_API_BASE_URL` to the API's public `/api` base URL.
4. Deploy and verify that direct links to `/products`, `/about`, `/register`, `/samples`, and `/contact` open correctly.

## End-to-end demonstration

Submit a sample request on the website, confirm the API responds with a created record, and verify it appears in MongoDB. Use Postman with the private admin key to list or update the request. Do not publish screenshots containing private credentials or buyer information.
