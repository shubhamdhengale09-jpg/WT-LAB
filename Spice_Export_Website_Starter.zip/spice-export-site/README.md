# Indian Spice Export Website

A learning project for a real Indian spice-export business. The same project is organized to support all ten Web Technology experiments, from the first responsive form through a MERN API and cloud deployment.

The business name, office address, phone, email, GSTIN, certifications, product grades, and export claims are intentionally left for the client to confirm. The catalogue descriptions are starter copy and should be checked with the business before publication.

## Project map

- `src/` — React website with Home, About, Products, Buyer Registration, Request a Sample, and Contact pages.
- `server/` — Express API, Mongoose models, MongoDB connection, and a seed script.
- `experiments/exp7-node-basics.js` — Node REPL companion exercises for HTTP, files, buffers, streams, and event-loop behavior.
- `experiments/exp5-mongodb.mongosh.js` — MongoDB collection and CRUD commands for the database experiment.
- `experiments/exp7-repl-guide.md` — short interactive Node REPL examples.
- `postman/Spice-Export-API.postman_collection.json` — requests for the REST API experiment.
- `DEPLOYMENT.md` — deployment outline for a React frontend, Express service, and MongoDB Atlas.
- `EXPERIMENT_MAP.md` — where each syllabus experiment fits in this project.

## Start the frontend

1. Install Node.js LTS and MongoDB locally, or create a MongoDB Atlas database for later experiments.
2. In this folder, run `npm install` (or `pnpm install` if you use pnpm).
3. Run `npm run dev` and open the local Vite address shown in the terminal.

The frontend can run on local catalogue data before the API is connected.

## Start the API when ready for Experiments 5–9

1. Copy `.env.example` to `.env` and set `MONGODB_URI` and a private `ADMIN_API_KEY`.
2. Run `npm run seed` once to add the sample spice catalogue to MongoDB.
3. In another terminal, run `npm run server`.
4. Use the Postman collection or `http://localhost:5000/api/health` to inspect the API.

Admin routes require the `x-admin-api-key` header. This simple key is included for a classroom CRUD demonstration only. Replace it with proper authentication and authorization before using private client or buyer data in production. Never put the admin key in React code or commit a real key to Git.

## Website status

The buyer registration page demonstrates Bootstrap styling and browser-side validation. It does not create an account or store a password. The sample-request API is the project’s intended client lead-capture flow. Keep API mode disabled until the backend and database are configured; then set `VITE_API_ENABLED=true` for the frontend build.
