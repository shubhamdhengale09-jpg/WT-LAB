import React from 'react';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import SiteLayout from './components/SiteLayout.jsx';
import AboutPage from './pages/AboutPage.jsx';
import ContactPage from './pages/ContactPage.jsx';
import HomePage from './pages/HomePage.jsx';
import ProductsPage from './pages/ProductsPage.jsx';
import RegisterPage from './pages/RegisterPage.jsx';
import SamplePage from './pages/SamplePage.jsx';

function NotFoundPage() {
  return <section className="container page-wrap"><span className="eyebrow">404</span>
    <h1>This page is still <em>on its way.</em></h1><Link className="text-link" to="/">Back to home →</Link></section>;
}

export default function App() {
  return <BrowserRouter>
    <Routes><Route element={<SiteLayout />}>
      <Route path="/" element={<HomePage />} />
      <Route path="/products" element={<ProductsPage />} />
      <Route path="/about" element={<AboutPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/samples" element={<SamplePage />} />
      <Route path="/contact" element={<ContactPage />} />
      <Route path="*" element={<NotFoundPage />} />
    </Route></Routes>
  </BrowserRouter>;
}
