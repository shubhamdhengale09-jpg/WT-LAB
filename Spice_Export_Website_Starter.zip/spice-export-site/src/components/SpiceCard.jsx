import React from 'react';
export default function SpiceCard({ spice, onRequestSample }) {
  return (
    <article className="spice-card">
      <div className={`spice-art spice-art-${spice.tone}`} aria-hidden="true">
        <span className="art-orbit art-orbit-one" />
        <span className="art-orbit art-orbit-two" />
        <span className="art-seed art-seed-one" />
        <span className="art-seed art-seed-two" />
        <span className="art-seed art-seed-three" />
        <span className="art-label">{spice.category}</span>
      </div>
      <div className="spice-card-body">
        <div className="spice-card-heading">
          <div><span className="eyebrow">{spice.botanicalName}</span><h3>{spice.name}</h3></div>
          <span className="origin-dot" title={`Origin: ${spice.origin}`} aria-label={`Origin: ${spice.origin}`}>IN</span>
        </div>
        <p>{spice.note}</p>
        <div className="spice-card-bottom">
          <span className={`availability${spice.sampleAvailable ? '' : ' unavailable'}`}>
            <span />{spice.sampleAvailable ? 'Sample available' : 'Ask for availability'}
          </span>
          <button className="icon-button" type="button" onClick={() => onRequestSample(spice)}
            aria-label={`Request a sample of ${spice.name}`}>
            <span aria-hidden="true">↗</span>
          </button>
        </div>
      </div>
    </article>
  );
}
