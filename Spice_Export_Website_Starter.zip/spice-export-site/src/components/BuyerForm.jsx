import React from 'react';
import { useState } from 'react';
import { createSampleRequest, isApiEnabled } from '../lib/api.js';

const initialValues = {
  name: '', company: '', email: '', country: '', product: '', password: '', confirmPassword: '',
};

export default function BuyerForm({ mode = 'register' }) {
  const [values, setValues] = useState(initialValues);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const isSampleForm = mode === 'sample';
  const formId = isSampleForm ? 'sampleRequestForm' : 'buyerRegistrationForm';

  const update = (event) => {
    const { name, value } = event.target;
    setValues((current) => ({ ...current, [name]: value }));
    if (name === 'password' || name === 'confirmPassword') setPasswordError('');
    setSubmitted(false);
    setSubmitError('');
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const passwordsMatch = isSampleForm || values.password === values.confirmPassword;
    setPasswordError(passwordsMatch ? '' : 'Passwords must match.');
    if (!form.checkValidity() || !passwordsMatch) {
      form.classList.add('was-validated');
      return;
    }
    if (isSampleForm && isApiEnabled) {
      setSubmitting(true);
      try {
        await createSampleRequest(values);
      } catch {
        setSubmitError('We could not send the request. Please try again later.');
        setSubmitting(false);
        return;
      }
      setSubmitting(false);
    }
    setSubmitted(true);
    form.classList.remove('was-validated');
    setValues(initialValues);
  };

  return (
    <form id={formId} className="needs-validation buyer-form" noValidate onSubmit={handleSubmit}>
      <div className="row g-3">
        <div className="col-md-6">
          <label className="form-label" htmlFor={`${formId}-name`}>Full name</label>
          <input id={`${formId}-name`} className="form-control" name="name" value={values.name}
            onChange={update} autoComplete="name" required />
          <div className="invalid-feedback">Please enter your name.</div>
        </div>
        <div className="col-md-6">
          <label className="form-label" htmlFor={`${formId}-company`}>Company</label>
          <input id={`${formId}-company`} className="form-control" name="company" value={values.company}
            onChange={update} autoComplete="organization" required />
          <div className="invalid-feedback">Please enter your company name.</div>
        </div>
        <div className="col-md-6">
          <label className="form-label" htmlFor={`${formId}-email`}>Business email</label>
          <input id={`${formId}-email`} className="form-control" type="email" name="email" value={values.email}
            onChange={update} autoComplete="email" required />
          <div className="invalid-feedback">Enter a valid email address.</div>
        </div>
        <div className="col-md-6">
          <label className="form-label" htmlFor={`${formId}-country`}>Country</label>
          <input id={`${formId}-country`} className="form-control" name="country" value={values.country}
            onChange={update} autoComplete="country-name" required />
          <div className="invalid-feedback">Please enter your country.</div>
        </div>
        <div className="col-12">
          <label className="form-label" htmlFor={`${formId}-product`}>Spice of interest</label>
          <select id={`${formId}-product`} className="form-select" name="product" value={values.product}
            onChange={update} required>
            <option value="">Choose a product</option>
            <option>Turmeric</option><option>Black Pepper</option><option>Green Cardamom</option>
            <option>Red Chilli</option><option>Cumin</option><option>Coriander Seed</option>
          </select>
          <div className="invalid-feedback">Choose a spice to continue.</div>
        </div>
        {!isSampleForm && <>
          <div className="col-md-6">
            <label className="form-label" htmlFor={`${formId}-password`}>Create password</label>
            <input id={`${formId}-password`} className="form-control" type="password" name="password"
              value={values.password} onChange={update} minLength="8" autoComplete="new-password" required />
            <div className="invalid-feedback">Use at least 8 characters.</div>
          </div>
          <div className="col-md-6">
            <label className="form-label" htmlFor={`${formId}-confirm`}>Confirm password</label>
            <input id={`${formId}-confirm`} className="form-control" type="password" name="confirmPassword"
              value={values.confirmPassword} onChange={update} autoComplete="new-password" required />
            <div className="invalid-feedback">Please confirm your password.</div>
            {passwordError && <div className="form-error" role="alert">{passwordError}</div>}
          </div>
        </>}
      </div>
      <div className="form-submit-row">
        <button className="button button-dark" type="submit" disabled={submitting}>
          {submitting ? 'Sending request…' : isSampleForm ? 'Send sample request' : 'Register as a buyer'}
          {!submitting && <span aria-hidden="true">↗</span>}
        </button>
        <small>{isSampleForm ? (isApiEnabled ? 'Your request will be sent to the sample-request service.' : 'This starter form displays a local confirmation only.') : 'Buyer registration is a frontend demonstration at this stage.'}</small>
      </div>
      {submitError && <p className="form-error" role="alert">{submitError}</p>}
      {submitted && <div className="form-success" role="status">
        <span className="success-mark" aria-hidden="true">✓</span>
        <div><strong>{isSampleForm ? 'Sample request prepared.' : 'Registration details are valid.'}</strong>
          <p>{isSampleForm ? (isApiEnabled ? 'The business can review your request.' : 'The request is ready for the business to review when the API is connected.') : 'The account will be connected to a database in a later experiment.'}</p></div>
      </div>}
    </form>
  );
}
