import React from 'react';
import { useEffect } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';

const navigation = [
  { to: '/', label: 'Home', end: true },
  { to: '/products', label: 'Our spices' },
  { to: '/about', label: 'About' },
  { to: '/contact', label: 'Contact' },
];

export default function SiteLayout() {
  const location = useLocation();

  useEffect(() => {
    const sectionName = location.pathname === '/' ? 'Home' : location.pathname.slice(1);
    document.title = `${sectionName.replace('-', ' ')} | Indian Spice Export`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  return (
    <div className="site-shell">
      <div className="announcement-bar">
        <span>Indian spices, prepared for conversations with the world</span>
        <Link to="/samples">Request a product sample <span aria-hidden="true">↗</span></Link>
      </div>

      <header className="site-header">
        <nav className="navbar navbar-expand-lg container site-nav" aria-label="Main navigation">
          <Link className="navbar-brand brand-lockup" to="/" aria-label="Indian Spice Export home">
            <span className="brand-mark" aria-hidden="true">S</span>
            <span className="brand-copy"><strong>INDIAN SPICE</strong><small>EXPORT HOUSE</small></span>
          </Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#siteNavigation" aria-controls="siteNavigation"
            aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon" />
          </button>
          <div className="collapse navbar-collapse justify-content-end" id="siteNavigation">
            <div className="navbar-nav align-items-lg-center gap-lg-4">
              {navigation.map((item) => (
                <NavLink key={item.to} to={item.to} end={item.end}
                  className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
                  {item.label}
                </NavLink>
              ))}
              <Link className="nav-cta" to="/register">Buyer registration <span aria-hidden="true">↗</span></Link>
            </div>
          </div>
        </nav>
      </header>

      <main><Outlet /></main>

      <footer className="site-footer">
        <div className="container footer-grid">
          <div>
            <Link className="brand-lockup footer-brand" to="/">
              <span className="brand-mark" aria-hidden="true">S</span>
              <span className="brand-copy"><strong>INDIAN SPICE</strong><small>EXPORT HOUSE</small></span>
            </Link>
            <p className="footer-note">A starting point for a growing Indian spice export business.</p>
          </div>
          <div className="footer-links">
            <Link to="/products">Explore spices</Link>
            <Link to="/samples">Request a sample</Link>
            <Link to="/contact">Contact</Link>
          </div>
          <p className="footer-meta">Business details and office location will be added with the client.</p>
        </div>
        <div className="container footer-bottom"><span>© {new Date().getFullYear()} Indian Spice Export</span><span>India</span></div>
      </footer>
    </div>
  );
}
