import React from 'react';
import { useEffect, useMemo, useState } from 'react';
import { categories, spices } from '../data/spices.js';
import SpiceCard from './SpiceCard.jsx';
import { getProducts, isApiEnabled } from '../lib/api.js';

export default function SpiceCatalog({ compact = false }) {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState('All spices');
  const [catalogue, setCatalogue] = useState(spices);
  const [catalogueNotice, setCatalogueNotice] = useState('');

  useEffect(() => {
    if (!isApiEnabled) return;
    let active = true;
    getProducts()
      .then((items) => { if (active) setCatalogue(items); })
      .catch(() => {
        if (active) setCatalogueNotice('Showing the starter catalogue. The product service is not available right now.');
      });
    return () => { active = false; };
  }, []);

  const visibleSpices = useMemo(() => catalogue.filter((spice) => {
    const matchesQuery = `${spice.name} ${spice.note}`.toLowerCase().includes(query.trim().toLowerCase());
    const matchesCategory = category === 'All spices' || spice.category === category;
    return matchesQuery && matchesCategory;
  }), [catalogue, query, category]);

  const requestSample = (spice) => {
    if (!spice.sampleAvailable) {
      window.alert(`Please contact us to check sample availability for ${spice.name}.`);
      return;
    }
    const confirmed = window.confirm(`Would you like to request a ${spice.name} sample?`);
    if (confirmed) window.alert(`Your ${spice.name} sample request is ready. Please complete the sample form.`);
  };

  return (
    <section className={`catalog-section${compact ? ' catalog-compact' : ''}`}>
      {!compact && <div className="catalog-heading">
        <div><span className="eyebrow">THE CATALOGUE</span><h2>Spices with a story<br />in every seed.</h2></div>
        <p>Explore a first selection of Indian spices. Product grades, pack sizes, and specifications can be added with the client.</p>
      </div>}
      <div className="catalog-controls">
        <label className="search-field">
          <span aria-hidden="true">⌕</span>
          <input value={query} onChange={(event) => setQuery(event.target.value)}
            placeholder="Search spices" aria-label="Search spices" />
          {query && <button type="button" onClick={() => setQuery('')} aria-label="Clear search">×</button>}
        </label>
        <div className="category-filter" aria-label="Filter by category">
          {categories.map((item) => <button key={item} type="button"
            className={category === item ? 'selected' : ''} onClick={() => setCategory(item)}>{item}</button>)}
        </div>
      </div>
      {catalogueNotice && <p className="catalog-notice" role="status">{catalogueNotice}</p>}
      {visibleSpices.length ? <div className="spice-grid">
        {visibleSpices.slice(0, compact ? 3 : undefined).map((spice) =>
          <SpiceCard key={spice.id} spice={spice} onRequestSample={requestSample} />)}
      </div> : <div className="empty-state"><strong>No spices found.</strong><span>Try another name or category.</span></div>}
    </section>
  );
}
