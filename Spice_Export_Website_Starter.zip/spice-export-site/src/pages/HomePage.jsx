import React from 'react';
import { Link } from 'react-router-dom';
import SpiceCatalog from '../components/SpiceCatalog.jsx';

export default function HomePage() {
  return <>
    <section className="hero-section">
      <div className="container hero-grid">
        <div className="hero-copy">
          <div className="eyebrow hero-eyebrow"><span /> FROM INDIA, FOR THE WORLD</div>
          <h1>Good food begins<br />with <em>good spice.</em></h1>
          <p>Discover a thoughtful selection of Indian spices for buyers looking to build lasting supply partnerships.</p>
          <div className="hero-actions">
            <Link className="button button-dark" to="/products">Explore our spices <span aria-hidden="true">↗</span></Link>
            <Link className="text-link" to="/about">Meet the business <span aria-hidden="true">→</span></Link>
          </div>
          <div className="hero-footnote"><span>01</span><span>Indian origin</span><i /> <span>Buyer-first conversations</span></div>
        </div>
        <div className="hero-art" aria-label="Illustration of warm spices in a bowl" role="img">
          <div className="hero-sun" />
          <div className="hero-ring ring-one" /><div className="hero-ring ring-two" />
          <div className="hero-bowl"><div className="bowl-rim" /><div className="bowl-spice" />
            <span className="spice-dot dot-one" /><span className="spice-dot dot-two" />
            <span className="spice-dot dot-three" /><span className="spice-dot dot-four" />
          </div>
          <span className="art-caption caption-top">ROOTED IN INDIA</span>
          <span className="art-caption caption-bottom">A WORLD OF FLAVOUR</span>
          <span className="hero-stamp">A good<br />place to<br />begin.</span>
        </div>
      </div>
      <div className="hero-bottom container"><span>SPICE, SOURCED WITH CARE</span><span>SCROLL TO EXPLORE ↓</span></div>
    </section>

    <section className="intro-strip">
      <div className="container intro-grid">
        <span className="eyebrow">A NOTE FROM INDIA</span>
        <p>We are building a direct line between Indian spices and the people around the world who bring them to the table.</p>
        <Link className="round-link" to="/about" aria-label="Read about the business">↗</Link>
      </div>
    </section>

    <div className="container section-container"><SpiceCatalog compact /></div>

    <section className="sample-banner">
      <div className="container sample-banner-inner">
        <div><span className="eyebrow">START A CONVERSATION</span><h2>Curious about a spice?<br /><em>Let’s begin with a sample.</em></h2></div>
        <Link className="button button-light" to="/samples">Request a sample <span aria-hidden="true">↗</span></Link>
      </div>
    </section>
  </>;
}
