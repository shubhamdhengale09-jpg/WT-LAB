import React from 'react';
import SpiceCatalog from '../components/SpiceCatalog.jsx';

export default function ProductsPage() {
  return <div className="page-wrap container">
    <div className="page-intro"><span className="eyebrow">THE COLLECTION</span><h1>Meet the spices.</h1>
      <p>A growing selection of Indian spices for export conversations. Details such as grades, harvests, packaging, and certifications can be added after the client confirms them.</p>
    </div>
    <SpiceCatalog />
  </div>;
}
