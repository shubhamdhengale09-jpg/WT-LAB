import React from 'react';
import { Link } from 'react-router-dom';

export default function ContactPage() {
  return <div className="page-wrap container contact-page">
    <div className="contact-heading"><span className="eyebrow">CONTACT</span><h1>Let’s talk<br /><em>spices and supply.</em></h1>
      <p>For product questions, sample requests, or export enquiries, get in touch with the business.</p></div>
    <div className="contact-grid">
      <div className="contact-card"><span className="eyebrow">OFFICE</span><h2>India</h2>
        <p>The client’s office address and map location will be added here.</p>
        <span className="map-placeholder">OFFICE LOCATION TO BE ADDED</span></div>
      <div className="contact-card contact-dark"><span className="eyebrow">BUYER ENQUIRIES</span><h2>Tell us<br />what you need.</h2>
        <p>The client’s business email and phone number will be added after confirmation.</p>
        <Link className="button button-light" to="/samples">Request a sample <span aria-hidden="true">↗</span></Link></div>
    </div>
    <p className="business-detail-note">GSTIN and other business registration details can be added when the client provides them.</p>
  </div>;
}
