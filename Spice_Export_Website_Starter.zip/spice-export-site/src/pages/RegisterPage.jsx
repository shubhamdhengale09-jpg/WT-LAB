import React from 'react';
import BuyerForm from '../components/BuyerForm.jsx';

export default function RegisterPage() {
  return <div className="form-page container">
    <div className="form-page-intro"><span className="eyebrow">FOR TRADE BUYERS</span><h1>Let’s get to know<br /><em>your business.</em></h1>
      <p>Share a few details and the spices you are interested in. This starter form checks the information in your browser; account creation will be added with the backend experiments.</p>
      <div className="form-aside-note"><span>01</span><p>Designed for a first conversation, with room to grow into a full buyer account.</p></div>
    </div>
    <div className="form-panel"><BuyerForm /><p className="privacy-note">Your details stay in this browser demo and are not sent to a server.</p></div>
  </div>;
}
