import React from 'react';
import BuyerForm from '../components/BuyerForm.jsx';

export default function SamplePage() {
  return <div className="form-page container sample-page">
    <div className="form-page-intro"><span className="eyebrow">A FIRST TASTE</span><h1>Start with a<br /><em>sample.</em></h1>
      <p>Tell us which spice you would like to explore and how to reach you. The business can follow up with availability and sample details.</p>
      <div className="form-aside-note"><span>02</span><p>Sample availability and shipping details will be confirmed by the client.</p></div>
    </div>
    <div className="form-panel"><BuyerForm mode="sample" /><p className="privacy-note">This form shows a local confirmation only. It does not send or store your request.</p></div>
  </div>;
}
