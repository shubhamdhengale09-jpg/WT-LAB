import React from 'react';
import { Link } from 'react-router-dom';

export default function AboutPage() {
  return <div className="page-wrap container">
    <div className="about-hero"><div><span className="eyebrow">ABOUT THE BUSINESS</span>
      <h1>From an Indian<br />beginning, to <em>everywhere.</em></h1></div>
      <p>This page will tell the client’s real story: how the business began, what it believes about sourcing, and how it plans to serve buyers around the world.</p>
    </div>
    <div className="about-grid">
      <div className="about-number">01<span>THE PURPOSE</span></div>
      <div className="about-copy"><h2>Good partnerships<br />start with <em>clarity.</em></h2>
        <p>The website is being shaped around clear product information, straightforward sample requests, and direct contact with the business. Verified details about the team, sourcing, processing, and export capabilities will be added with the client.</p>
        <Link className="text-link" to="/contact">Talk with the team <span aria-hidden="true">→</span></Link>
      </div>
      <div className="about-note"><span className="note-symbol">✳</span><p>Built around real client details. Product specifications and certifications will be published only after the business confirms them.</p></div>
    </div>
  </div>;
}
